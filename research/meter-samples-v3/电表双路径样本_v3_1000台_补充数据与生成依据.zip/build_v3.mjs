import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const dir=path.dirname(fileURLToPath(import.meta.url));
const p=JSON.parse(await fs.readFile(path.join(dir,'workbook_payload.json'),'utf8'));
const wb=Workbook.create();
const names=['总览','样本主表','制造模型输入','出厂检测','加速老化检测','互感器多点曲线','校准模拟参数','元件装配','批次配方','批次抽样','故障机制','来源与假设','元件抽检来源','来源映射'];
const sheets=Object.fromEntries(names.map(n=>[n,wb.worksheets.add(n)]));
const col=n=>{let s='';for(;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
const labels={sample_id:'样本ID',batch_id:'虚拟生产批次',route:'检测路径',sample_label:'正负样本',result_scope:'结论适用范围',initial_test_fail:'基线检测异常(0/1)',first_observed_fail_h:'首次检出异常(h)',aging_new_failure:'老化后新检出(0/1)',factory_label:'出厂路径标签',aging_label:'老化路径标签',lifetime_health:'长期健康状态',split:'数据划分',provenance:'数据性质',test_id:'检测ID',test_stage:'检测阶段',exposure_h:'累计受应力(h)',measurement_temp_C:'检测温度(℃)',measurement_RH_pct:'检测湿度(%RH)',measurement_voltage_Un:'检测电压(Un倍数)',recovery_h:'恢复时间(h)',stress_temp_C:'受应力温度(℃)',stress_RH_pct:'受应力湿度(%RH)',stress_voltage_Un:'受应力电压(Un倍数)',stress_current_A:'受应力电流(A)',comm_trials:'通信试验次数',comm_failures:'通信失败次数',comm_success_rate:'通信成功率',lcd_expected_segments:'应亮段数',lcd_missing_segments:'缺段数',lcd_missing_positions:'缺段位置',metering_fail:'计量异常(0/1)',communication_fail:'通信异常(0/1)',display_fail:'显示异常(0/1)',any_fail:'任一项异常(0/1)',
conveyor_reading_sim_cm_min:'传送速度模拟读数(cm/min)',placement_offset_sim_mm:'模拟位置偏移(mm)',gain_compensation_increment_sim_pct:'模拟增益补偿增量(百分点)',phase_compensation_increment_sim_arcmin:'模拟相位补偿增量(角分)',cleaning_residue_proxy:'清洁残留代理(无量纲)',rs485_incoming_margin_proxy:'RS485来料裕量代理',lcd_incoming_margin_proxy:'LCD来料裕量代理',process_sequence_available:'制造过程时序可用(0/1)',
recipe_id:'模拟配方ID',recipe_version:'模拟配方版本',conveyor_set_cm_min:'配方速度(cm/min)',wave_preheat_1_set_C:'波峰预热1设定(℃)',wave_preheat_2_set_C:'波峰预热2设定(℃)',wave_preheat_3_set_C:'波峰预热3设定(℃)',wave_solder_set_C:'锡炉设定(℃)',wave_flux_value_raw:'助焊剂原值(单位待确认)',wave_flux_unit:'助焊剂单位(未知留空)',wave_height1_raw:'波峰1高度原值',wave_height2_raw:'波峰2高度原值',wave_height_unit:'波峰高度单位(未知留空)',process_source:'配方来源位置',process_scope:'配方适用说明',
ct_sim_lot:'CT虚拟装配批次',ct_model:'CT来源型号',ct_reference_lot:'CT来源抽检批次',crystal_sim_lot:'晶振虚拟装配批次',crystal_model:'晶振来源型号',crystal_reference_lot:'晶振来源抽检批次',crystal_load_capacitance_pF:'来源负载电容(pF)',crystal_reference_ppm:'来源晶振频差(ppm，背景)',crystal_frequency_Hz:'规范频率(Hz，待确认)',crystal_frequency_status:'频率单位确认状态',lcd_sim_lot:'LCD虚拟装配批次',rs485_sim_lot:'RS485虚拟装配批次',assembly_status:'虚拟装配说明',enterprise_barcode:'企业条码(未知留空)',meter_model:'整表型号(未知留空)',production_date:'生产日期(未知留空)',
total:'批内电表数',aging_sample_n:'老化抽测台数',factory_only_n:'未老化出厂台数',aging_negative_n:'老化路径负样本数',aging_new_failure_n:'老化新检出异常台数',factory_negative_n:'出厂路径负样本数',
direction:'电流变化方向',anchor:'原始电流锚点标识',current_fraction_100pct:'相对100%参考电流',ratio_sim_pct:'模拟比差(%)',phase_sim_arcmin:'模拟角差(角分)',source_sample:'来源抽检样品号',source_cells:'原始单元格',reference_ct_ratio_pct:'参考CT100%升流比差(%)',reference_ct_phase_arcmin:'参考CT100%升流角差(角分)',calibration_anchor:'补偿参考点',hardware_register_gain:'实际增益寄存器(未知)',hardware_register_phase:'实际相位寄存器(未知)',
component:'元件/位置',test_regime:'原始测试制度',current_A:'原始测试电流(A)',ratio_pct:'原始比差(%)',phase_arcmin:'原始角差(角分)',crystal_ppm:'原始晶振频差(ppm)',source_file:'来源文件',source_sheet:'来源工作表',usage:'本版用途',
source_background_meter:'背景来源表号',ct_source_sample:'CT来源抽检样品号',crystal_source_sample:'晶振来源抽检样品号',source_component_file:'元件来源文件',ct_source_cells:'CT来源单元格',crystal_source_cell:'晶振来源单元格',mapping_status:'匹配性质',
mechanism:'仿真机制ID',upstream:'上游偏离',defect:'中间缺陷假设',effect:'电气影响',symptom:'可能故障域',item:'项目',setting:'本版设置',source:'来源或依据',limit:'适用边界'};
function label(k){
 if(labels[k])return labels[k];
 let m=k.match(/^reflow_zone_(\d+)_reading_sim_C$/);if(m)return `回流${Number(m[1])}区模拟读数(℃)`;
 m=k.match(/^reflow_zone_(\d+)_set_C$/);if(m)return `回流${Number(m[1])}区配方设定(℃)`;
 m=k.match(/^ct_(up|down)_(\d+)_(ratio_sim_pct|phase_sim_arcmin)$/);if(m)return `CT${m[1]==='up'?'升':'降'}流${Number(m[2])}%${m[3]==='ratio_sim_pct'?'模拟比差(%)':'模拟角差(角分)'}`;
 m=k.match(/^error_(.*)_pct$/);if(m)return `${m[1]}误差(%)`;
 return k;
}
const manifests=[];
function table(name,key){
 const rows=p[key],s=sheets[name],keys=Object.keys(rows[0]),last=col(keys.length),n=rows.length+1;
 const range=s.getRange(`A1:${last}${n}`);range.values=[keys.map(label),...rows.map(x=>keys.map(k=>x[k]??null))];
 s.showGridLines=false;range.format.font={name:'Arial',size:10};range.format.rowHeight=25;range.format.columnWidth=24;range.format.verticalAlignment='center';
 for(let j=0;j<keys.length;j++){
  const k=keys[j],c=col(j+1),rr=s.getRange(`${c}2:${c}${n}`),v=rows.map(x=>x[k]).filter(x=>x!==null&&x!==undefined);
  const numeric=v.length&&v.every(x=>typeof x==='number');
  rr.setNumberFormat(numeric?(v.every(Number.isInteger)?'0':k==='comm_success_rate'?'0.0%':k.startsWith('error_')?'0.000000':'0.0000'):'@');
  rr.format.horizontalAlignment=numeric?'right':'left';
  if(['source_file','source_component_file','process_source','ct_source_cells'].includes(k)){
   s.getRange(`${c}1:${c}${n}`).format.columnWidth=58;rr.format.wrapText=true;
  }
  if(['assembly_status','frequency_status','crystal_frequency_status','usage','process_scope','mapping_status','provenance'].includes(k)){
   s.getRange(`${c}1:${c}${n}`).format.columnWidth=43;rr.format.wrapText=true;
  }
 }
 s.getRange(`A1:${last}1`).format={fill:'#263F5B',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},rowHeight:55,wrapText:true,horizontalAlignment:'center',verticalAlignment:'center'};
 s.freezePanes.freezeRows(1);s.tables.add(`A1:${last}${n}`,true,'MeterV3Table'+names.indexOf(name));
 manifests.push({sheet:name,key,fields:keys,headers:keys.map(label),rows:rows.length});
 return s;
}
for(const [name,key] of [['样本主表','units'],['制造模型输入','features'],['出厂检测','factory'],['加速老化检测','aging'],['互感器多点曲线','curves'],['校准模拟参数','calibrations'],['元件装配','assemblies'],['批次配方','recipes'],['批次抽样','batches'],['故障机制','chains'],['来源与假设','assumptions'],['元件抽检来源','source_records'],['来源映射','traces']])table(name,key);
for(const name of ['元件装配','来源映射','元件抽检来源','批次配方']){
 const m=manifests.find(x=>x.sheet===name);sheets[name].getRange(`A2:${col(m.fields.length)}${m.rows+1}`).format.rowHeight=46;
}
for(const name of ['故障机制','来源与假设']){
 const m=manifests.find(x=>x.sheet===name),s=sheets[name];s.getRange(`A2:${col(m.fields.length)}${m.rows+1}`).format.wrapText=true;s.getRange(`A2:${col(m.fields.length)}${m.rows+1}`).format.rowHeight=name==='故障机制'?56:70;
 s.getRange(`A1:A${m.rows+1}`).format.columnWidth=24;
 s.getRange(`B1:${col(m.fields.length)}${m.rows+1}`).format.columnWidth=name==='故障机制'?35:52;
}
sheets['来源与假设'].tabColor='#758493';
const s=sheets['总览'];s.tabColor='#263F5B';s.showGridLines=false;
s.getRange('A1:F30').format={font:{name:'Arial',size:11},rowHeight:27,columnWidth:22,verticalAlignment:'center'};
s.getRange('A1:A30').format.columnWidth=29;s.getRange('E1:E30').format.columnWidth=25;
s.getRange('A2').values=[['电表双路径半合成样本 · v3补充版']];s.getRange('A2').format.font={name:'Arial',size:16,bold:true,color:'#263F5B'};
s.getRange('A4:D4').values=[['检测路径','正样本','负样本','合计']];s.getRange('A5:A7').values=[['未老化出厂检测'],['加速老化抽测'],['合计']];
for(let i=5;i<=6;i++){
 s.getRange('B'+i).formulas=[[`=COUNTIFS('样本主表'!$C$2:$C$1001,A${i},'样本主表'!$D$2:$D$1001,"正样本")`]];
 s.getRange('C'+i).formulas=[[`=COUNTIFS('样本主表'!$C$2:$C$1001,A${i},'样本主表'!$D$2:$D$1001,"负样本")`]];
 s.getRange('D'+i).formulas=[[`=SUM(B${i}:C${i})`]];
}
s.getRange('B7:D7').formulas=[['=SUM(B5:B6)','=SUM(C5:C6)','=SUM(D5:D6)']];
s.getRange('B5:D7').setNumberFormat('#,##0');s.getRange('A7:D7').format.font={name:'Arial',size:11,bold:true};
s.getRange('A9').values=[['正负数量比']];s.getRange('B9').formulas=[['=B7/C7']];s.getRange('B9').setNumberFormat('0.000');s.getRange('C9').values=[['约5:1，整数最近配置']];
s.getRange('A12:B12').values=[['老化负样本构成','电表数']];s.getRange('A13:A14').values=[['老化前已异常'],['老化后新检出异常']];
for(let i=13;i<=14;i++)s.getRange('B'+i).formulas=[[`=COUNTIFS('样本主表'!$E$2:$E$1001,A${i})`]];
s.getRange('A17:C17').values=[['数据划分','电表数','用途']];s.getRange('A18:A20').values=[['train'],['validation'],['test']];
for(let i=18;i<=20;i++)s.getRange('B'+i).formulas=[[`=COUNTIFS('样本主表'!$L$2:$L$1001,A${i})`]];
s.getRange('C18:C20').values=[['训练预处理及模型'],['调参'],['仿真留出验证']];
s.getRange('E12:F12').values=[['记录规模','数量']];s.getRange('E13:F16').values=[['独立合成电表',1000],['检测次数',2000],['计量点数',20000],['CT多点曲线行',6000]];
const notes=['正样本=本路径观察窗内通过；负样本=至少一项检测失败。','每批20台，4台老化。抽测结论不替代其余16台的个体检测。','补充多点CT、独立增益/相位补偿、元件追溯和配方，未加入日计时误差。','全部为半合成；原始值与虚拟装配、模拟读数和机制参数已区分。','CT相对电流映射与判据为假设；轴外保持端点，详见来源与假设。','Excel是数据快照；改配置后运行脚本重生成，不要直接改标签。'];
notes.forEach((v,i)=>s.getRange('A'+(23+i)).values=[[v]]);
for(const r of ['A4:D4','A12:B12','A17:C17','E12:F12'])s.getRange(r).format={fill:'#263F5B',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},rowHeight:30,horizontalAlignment:'center'};
wb.recalculate();
console.log((await wb.inspect({kind:'table',range:'总览!A4:D20',include:'values,formulas',tableMaxRows:17,tableMaxCols:4,maxChars:2200})).ndjson);
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:20},maxChars:800})).ndjson);
const previews=path.join(dir,'previews');await fs.mkdir(previews,{recursive:true});
for(const name of names){
 const range=name==='总览'?'A1:F29':name==='来源与假设'?'A1:D7':name==='故障机制'?'A1:F6':'A1:F7';
 const b=await wb.render({sheetName:name,range,scale:1,format:'png'});await fs.writeFile(path.join(previews,name+'.png'),new Uint8Array(await b.arrayBuffer()));
}
// Also inspect error values at the far right of each detection table.
for(const name of ['出厂检测','加速老化检测']){
 const b=await wb.render({sheetName:name,range:'U1:AD7',scale:1,format:'png'});await fs.writeFile(path.join(previews,name+'_结果.png'),new Uint8Array(await b.arrayBuffer()));
}
await(await SpreadsheetFile.exportXlsx(wb)).save(path.join(dir,'电表双路径正负样本_1000条_v3_补充版.xlsx'));
await fs.writeFile(path.join(dir,'workbook_manifest.json'),JSON.stringify(manifests,null,2));
console.log('EXPORTED '+names.length+' sheets');
