"""Reproducible semi-synthetic meter dataset. No clock/timekeeping output is read or generated."""
import argparse
import csv
import hashlib
import json
import math
import shutil
import sys
from collections import Counter
from pathlib import Path

import numpy as np
import openpyxl

ROOT = Path(__file__).resolve().parent
FILES = {
    'aging': '单相表-20版正面布局的耐久性（可靠性）试验数据26.3.6.xlsx',
    'component': '晶振和互感器10个样品的检验数据26.3.11.xlsx',
    'process': '样品出厂检测和数字化电路板生产过程数据26.xlsx',
}
CONDITIONS = ['Imin_1.0', 'Imin_0.5L', 'Itr_1.0', 'Itr_0.5L', '10Itr_1.0', '10Itr_0.5L', 'Imax_half_1.0', 'Imax_half_0.5L', 'Imax_1.0', 'Imax_0.5L']
ANCHORS = ['5%', '20%', '100%', '100%20A', '210%20A', 'Imax60%']
CHAINS = [
    ('CT_RESIDUAL', '互感器多点偏差与增益/相位补偿不匹配', '互感器及采样通道', '增益与相位残差', '电流及功率因数相关计量偏差', '计量超差'),
    ('SAMPLING_SOLDER', '回流设备温度及速度偏离配方', '采样连接点', '润湿或接触裕量下降', '采样增益衰减', '计量超差'),
    ('PCB_RESIDUE', '焊后清洁控制不足的模拟代理', '高阻采样节点', '残留吸湿及寄生泄漏', '小电流相对偏置放大', '小电流计量超差'),
    ('RS485_JOINT', '焊接偏差及连接裕量不足', '假设为回流装配的RS485接口连接', '连接稳定性下降', '报文收发失败增加', '通信异常'),
    ('LCD_CONTACT', '贴装位置偏移及连接裕量不足', 'LCD SEG/COM连接', '连接不可靠', '部分段不能点亮', '显示缺段'),
]


def jd(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def dump(p, x):
    Path(p).write_text(json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def save(p, rows):
    with Path(p).open('w', encoding='utf-8-sig', newline='') as h:
        wr = csv.DictWriter(h, fieldnames=list(rows[0]))
        wr.writeheader()
        wr.writerows(rows)


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def read_sources(raw):
    # Bounded reads: aging files contain oversized formatting on unrelated sheets.
    ws = {k: openpyxl.load_workbook(raw / n, data_only=True, read_only=True) for k, n in FILES.items()}
    grid = list(ws['aging']['基本误差'].iter_rows(min_row=1, max_row=67, max_col=32, values_only=True))
    groups, refs = [], []
    for t in range(6):
        groups.append({str(grid[1 + 11*t][c]): [float(grid[2 + 11*t+j][c]) for j in range(10)] for c in range(2, 32)})
        refs.append({str(grid[1 + 11*t][c]): [f'{openpyxl.utils.get_column_letter(c+1)}{3+11*t+j}' for j in range(10)] for c in range(2, 32)})
    ids = sorted(set.intersection(*(set(g) for g in groups)), key=int)
    trajectories = {i: np.array([g[i] for g in groups]) for i in ids}
    s = ws['component']['互感器测试数据']
    cg = list(s.iter_rows(min_row=1, max_row=37, max_col=32, values_only=True))
    ac = np.empty((10, 2, 6, 2))
    records = []
    for j in range(10):
        for direction in range(3):
            row = 8 + 3*j + direction
            for k, label in enumerate(ANCHORS):
                ratio = float(cg[row-1][20+2*k]); phase = float(cg[row-1][21+2*k])
                if direction < 2:
                    ac[j, direction, k] = [ratio, phase]
                records.append(dict(source_sample=j+1, component='互感器', test_regime='交流升降流', direction=['升', '降', '原表变差'][direction], anchor=label,
                                    current_fraction_100pct=[.05, .2, 1, None, None, None][k], current_A=None,
                                    ratio_pct=ratio, phase_arcmin=phase, crystal_ppm=None,
                                    source_file=FILES['component'], source_sheet='互感器测试数据', source_cells=f'{openpyxl.utils.get_column_letter(21+2*k)}{row}:{openpyxl.utils.get_column_letter(22+2*k)}{row}',
                                    usage='前3点升/降流参与计量，其余保留来源与核对'))
        for k, amps in enumerate([.5, 2.5, 5, 10, 28, 42, 60, 72]):
            row = 8+j
            records.append(dict(source_sample=j+1, component='互感器', test_regime='抗直流', direction='原表', anchor=f'{amps}A', current_fraction_100pct=None, current_A=amps,
                                ratio_pct=float(cg[row-1][1+2*k]), phase_arcmin=float(cg[row-1][2+2*k]), crystal_ppm=None,
                                source_file=FILES['component'], source_sheet='互感器测试数据', source_cells=f'{openpyxl.utils.get_column_letter(2+2*k)}{row}:{openpyxl.utils.get_column_letter(3+2*k)}{row}',
                                usage='独立原始记录，不输入普通交流计量响应'))
    sx = list(ws['component']['晶振测试数据'].iter_rows(min_row=1, max_row=12, max_col=6, values_only=True))
    crystal = [float(sx[2+j][5]) for j in range(10)]
    for j, ppm in enumerate(crystal):
        records.append(dict(source_sample=j+1, component='晶振', test_regime='来料频差', direction=None, anchor=None, current_fraction_100pct=None, current_A=None,
                            ratio_pct=None, phase_arcmin=None, crystal_ppm=ppm, source_file=FILES['component'], source_sheet='晶振测试数据', source_cells=f'F{3+j}', usage='元件背景及模拟装配元数据，不参与标签和模型输入'))
    pg = list(ws['process']['确认版'].iter_rows(min_row=1, max_row=85, max_col=4, values_only=True))
    z = np.array([float(str(pg[r-1][0]).replace('℃', '')) for r in range(55, 65)])
    metadata = dict(ct_model=str(cg[0][0]).replace('互感器型号：', ''), ct_source_lot='20251220',
                    crystal_model=str(sx[2][0]), crystal_source_lot=str(sx[2][1]), crystal_load_capacitance_pF=float(sx[2][3]),
                    crystal_frequency_original=str(sx[2][2]), crystal_frequency_Hz=None, frequency_status='原Hz表头与3.5795数值待企业确认',
                    wave_preheat_C=[130, 140, 150], wave_solder_C=300, wave_flux_raw='0.2', wave_heights_raw='38.0/38.6', wave_units_status='喷涂量与波峰高度单位未确认')
    for w in ws.values():
        w.close()
    manifest = [dict(key=k, file=n, sha256=digest(raw/n), used_sheets={'aging':['基本误差'], 'component':['互感器测试数据','晶振测试数据'], 'process':['确认版']}[k]) for k, n in FILES.items()]
    return ids, trajectories, refs, ac, crystal, z, records, metadata, manifest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--raw', type=Path, default=ROOT/'sources')
    ap.add_argument('--out', type=Path, default=ROOT)
    ap.add_argument('--config', type=Path, default=ROOT/'config.json')
    args = ap.parse_args()
    out = args.out.resolve(); out.mkdir(parents=True, exist_ok=True)
    c = jd(args.config); rng = np.random.default_rng(c['seed'])
    ids, traj, refs, ac, crystals, zref, raw_records, metadata, manifest = read_sources(args.raw)
    split_rng = np.random.default_rng(c['split_seed'])
    order = list(split_rng.permutation(ids))
    source_split = {mid: ('train' if j < 19 else 'validation' if j < 24 else 'test') for j, mid in enumerate(order)}
    component_groups = {'train': list(range(6)), 'validation':[6,7], 'test':[8,9]}
    save(out/'元件抽检来源.csv', raw_records)
    dump(out/'原始规格与配方.json', metadata)
    dump(out/'source_manifest.json', manifest)
    if out/'config.json' != args.config.resolve():
        shutil.copy2(args.config, out/'config.json')
    slots, recipes = [], []
    for bi in range(c['batches']):
        mid = ids[bi % len(ids)]; split = source_split[mid]; bid = f'SIM3-B{bi+1:03d}'
        cj = int(rng.choice(component_groups[split])); xj = int(rng.choice(component_groups[split]))
        r = dict(batch_id=bid, recipe_id=f'SIM3-R{bi+1:03d}', recipe_version='SIM-v3.0', split=split, source_meter=mid, source_ct=cj, source_crystal=xj,
                 ct_lot=f'SIM3-CT{bi+1:03d}', crystal_lot=f'SIM3-XT{bi+1:03d}', lcd_lot=f'SIM3-LCD{bi+1:03d}', rs485_lot=f'SIM3-RS{bi+1:03d}',
                 residue_center=float(rng.uniform(.1,.25)), reflow_set_C=zref.tolist(), conveyor_set_cm_min=c['conveyor_center_cm_min'],
                 **{f'wave_preheat_{j+1}_set_C':v for j,v in enumerate(metadata['wave_preheat_C'])}, wave_solder_set_C=metadata['wave_solder_C'],
                 wave_flux_value_raw='0.2', wave_flux_unit=None, wave_height1_raw='38.0', wave_height2_raw='38.6', wave_height_unit=None,
                 process_source=f'{FILES["process"]}|确认版!A55:B64;A83:D85', process_scope='模拟批次引用原始配方；波峰焊仅作配方背景，不参与响应')
        recipes.append(r)
        aged = set(map(int, rng.choice(c['units_per_batch'], c['aging_per_batch'], replace=False)))
        for j in range(c['units_per_batch']):
            slots.append(dict(sample_id=f'SIM3-U{len(slots)+1:05d}', recipe=r, route='加速老化抽测' if j in aged else '未老化出厂检测', negative=False, delayed=False, scenario=0))
    # Prescribed study quotas, not estimated manufacturing fault prevalence.
    for route, quota in [('加速老化抽测', c['aging_negative']), ('未老化出厂检测', c['factory_negative'])]:
        selected = list(map(int, rng.choice([i for i,s in enumerate(slots) if s['route']==route], quota, replace=False)))
        delayed = set(selected[:c['aging_delayed_negative']]) if route=='加速老化抽测' else set()
        for j, i in enumerate(selected):
            slots[i].update(negative=True, delayed=i in delayed, scenario=j%len(CHAINS))

    limits = np.array(c['error_limits_pct']); phi = np.array([0, math.pi/3]*5)
    axis = np.array(c['ct_confirmed_fraction_axis'])
    eval_axis = np.repeat(c['condition_current_fraction_sim'], 2)
    leak_weights = np.repeat(c['leak_current_weights'], 2)

    def propose(slot):
        r=slot['recipe']; negative=slot['negative']; chain=slot['scenario'] if negative else int(rng.integers(5))
        source=ac[r['source_ct'], :, :3, :]
        # Correlated perturbations preserve each source specimen's multi-point and up/down pairing.
        shift=float(rng.normal(0,c['ct_ratio_shift_sd_pct'])); slope=float(rng.normal(0,c['ct_ratio_slope_sd_pct']))
        pshift=float(rng.normal(0,c['ct_phase_shift_sd_arcmin'])); pslope=float(rng.normal(0,c['ct_phase_slope_sd_arcmin']))
        gain_fraction=float(rng.uniform(*c['gain_comp_fraction_regular'])); phase_fraction=float(rng.uniform(*c['phase_comp_fraction_regular']))
        z=zref+rng.normal(0,c['equipment_reading_sd_C'],10); speed=float(c['conveyor_center_cm_min']+rng.normal(0,c['speed_sd_cm_min']))
        residue=max(0,float(r['residue_center']+rng.normal(0,c['residue_sd'])))
        offset=float(rng.normal(0,c['placement_offset_sd_mm'])); rs_margin=float(rng.uniform(*c['incoming_margin_regular'])); lcd_margin=float(rng.uniform(*c['incoming_margin_regular']))
        perturbed=negative or rng.random()<c['positive_proposal_perturb_probability']
        if perturbed:
            if chain==0:
                shift+=float(rng.choice([-1,1])*rng.uniform(*c['ct_fault_ratio_shift_pct']))
                pshift+=float(rng.choice([-1,1])*rng.uniform(*c['ct_fault_phase_shift_arcmin']))
                gain_fraction=float(rng.uniform(*c['gain_comp_fraction_defect'])); phase_fraction=float(rng.uniform(*c['phase_comp_fraction_defect']))
            elif chain in (1,3):
                z[7:]-=rng.uniform(*c['reflow_excursion_C']); speed+=rng.uniform(*c['speed_excursion_cm_min'])
                if chain==3: rs_margin=float(rng.uniform(*c['incoming_margin_defect']))
            elif chain==2: residue=float(rng.uniform(*c['residue_defect']))
            else:
                offset=float(rng.choice([-1,1])*rng.uniform(*c['placement_offset_defect_mm'])); lcd_margin=float(rng.uniform(*c['incoming_margin_defect']))
        bend=1-np.sqrt(axis)
        curves=source.copy()
        curves[:,:,0]+=shift+slope*bend+rng.normal(0,c['ct_ratio_point_noise_sd_pct'],(2,3))
        curves[:,:,1]+=pshift+pslope*bend+rng.normal(0,c['ct_phase_point_noise_sd_arcmin'],(2,3))
        # Increments relative to source 100% AC rising anchor, not undocumented register values.
        gain=-gain_fraction*(curves[0,2,0]-source[0,2,0])+rng.normal(0,c['gain_comp_noise_sd_pct'])
        phase=-phase_fraction*(curves[0,2,1]-source[0,2,1])+rng.normal(0,c['phase_comp_noise_sd_arcmin'])
        direction=int(rng.integers(2))
        raw_ratio=np.interp(eval_axis,axis,curves[direction,:,0])-source[0,2,0]
        raw_phase=np.interp(eval_axis,axis,curves[direction,:,1])-source[0,2,1]
        ratio_res=raw_ratio+gain; phase_res=raw_phase+phase
        heat=max(0,(float(np.mean(zref[7:]))-float(np.mean(z[7:])))/c['heat_temp_scale_C'])+max(0,(speed-c['conveyor_center_cm_min'])/c['heat_speed_scale_cm_min'])
        susceptibility=rng.lognormal(c['susceptibility_logmean'],c['susceptibility_logsd'],4); tolerance=rng.uniform(*c['tolerance_range'],4)
        ds=max(0,heat-tolerance[0])*susceptibility[0]
        dr=max(0,residue-tolerance[1])*susceptibility[1]
        dc=max(0,heat+c['connection_margin_weight']*(1-rs_margin)-tolerance[2])*susceptibility[2]
        dl=max(0,abs(offset)/c['offset_scale_mm']+c['lcd_heat_weight']*heat+c['connection_margin_weight']*(1-lcd_margin)-tolerance[3])*susceptibility[3]
        initial=rng.uniform(*c['initial_activation_regular'],5)
        if negative: initial[chain]=rng.uniform(*(c['initial_activation_delayed'] if slot['delayed'] else c['initial_activation_immediate']))
        rate=rng.uniform(*c['degradation_rate_range'],5); beta=float(rng.uniform(*c['degradation_exponent_range']))
        nsegments=c['lcd_digits']*c['segments_per_digit']
        segs=list(map(int,rng.choice(nsegments,c['lcd_candidate_connections'],replace=False))); segth=rng.uniform(*c['lcd_connection_thresholds'],len(segs))
        leak_sign=int(rng.choice([-1,1]))
        base=traj[r['source_meter']][0]+rng.normal(0,c['background_shared_noise_sd_pct'])+rng.normal(0,c['background_point_noise_sd_pct'],10)
        drift_scale=float(rng.uniform(*c['empirical_drift_scale_range']))
        noise=[rng.normal(0,c['measurement_noise_sd_pct'],10) for _ in c['hours']]

        def evaluate(disabled=None):
            results=[]
            hours=c['hours'] if slot['route']=='加速老化抽测' else [0]
            for t,h in enumerate(hours):
                growth=initial+rate*(h/c['hours'][-1])**beta
                damage=np.array([ds,dr,dc,dl])*growth[1:]
                if disabled in (1,2,3,4): damage[disabled-1]=0
                age=(traj[r['source_meter']][t]-traj[r['source_meter']][0])*drift_scale if h else np.zeros(10)
                background=base+age
                rr=ratio_res*growth[0] if disabled!=0 else np.zeros(10)
                pp=phase_res*growth[0]*math.pi/(180*60) if disabled!=0 else np.zeros(10)
                after_ct=100*((1+background/100)*(1+rr/100)*np.cos(phi+pp)/np.cos(phi)-1)
                solder=-c['solder_error_scale_pct']*damage[0]*np.ones(10)
                leak=leak_sign*c['leak_error_scale_pct']*damage[1]*leak_weights
                error=np.round(after_ct+solder+leak+noise[t],6)
                pfail=float(c['comm_baseline_fail_probability']+c['comm_damage_scale']*(1-np.exp(-damage[2])))
                # Common random numbers make mechanism removal comparisons meaningful.
                failures=int(np.sum(comm_uniforms[t]<pfail)); success=(c['communication_trials']-failures)/c['communication_trials']
                missing=[s for s,th in zip(segs,segth) if damage[3]>th]
                mf=int(np.any(abs(error)>limits)); cf=int(success<c['communication_min_success_rate']); lf=int(bool(missing))
                results.append(dict(t=t,h=h,error=error,age=age,ct_effect=after_ct-background,solder_effect=solder,leak_effect=leak,noise=noise[t],ratio_res=rr,phase_res_rad=pp,damage=damage,
                                    comm_failures=failures,success=success,missing=missing,mf=mf,cf=cf,lf=lf,bad=int(mf or cf or lf)))
            return results
        comm_uniforms=[rng.random(c['communication_trials']) for _ in c['hours']]
        results=evaluate(); observed=any(x['bad'] for x in results)
        accepted=observed==negative
        if negative:
            accepted=accepted and (not results[0]['bad'] if slot['delayed'] else bool(results[0]['bad']))
        return locals()

    units=[];features=[];tests=[];decomp=[];truth=[];traces=[];assemblies=[];sampling=[];logs=[];curve_rows=[];calibrations=[];counterfactual=[]
    for slot in slots:
        for attempt in range(1,c['max_proposals_per_meter']+1):
            a=propose(slot)
            if a['accepted']: break
        else: raise RuntimeError(f'No matching proposal for {slot["sample_id"]}')
        uid=slot['sample_id'];r=slot['recipe'];aged=slot['route']=='加速老化抽测'
        first=next((x['h'] for x in a['results'] if x['bad']),None); bad=first is not None; initial_bad=a['results'][0]['bad']; label='负样本' if bad else '正样本'
        status=('老化前已异常' if initial_bad else '老化后新检出异常' if bad else '老化窗口通过') if aged else ('出厂本次异常' if bad else '出厂本次通过')
        units.append(dict(sample_id=uid,batch_id=r['batch_id'],route=slot['route'],sample_label=label,result_scope=status,initial_test_fail=initial_bad,first_observed_fail_h=first,
                          aging_new_failure=int(aged and bad and not initial_bad),factory_label=label if not aged else None,aging_label=label if aged else None,lifetime_health='未知',split=r['split'],provenance='半合成-v3.0'))
        f=dict(sample_id=uid,**{f'reflow_zone_{j+1:02d}_reading_sim_C':float(v) for j,v in enumerate(a['z'])},conveyor_reading_sim_cm_min=a['speed'],placement_offset_sim_mm=a['offset'])
        for d, dn in enumerate(['up','down']):
            for k, kn in enumerate(['005','020','100']):
                f[f'ct_{dn}_{kn}_ratio_sim_pct']=float(a['curves'][d,k,0]); f[f'ct_{dn}_{kn}_phase_sim_arcmin']=float(a['curves'][d,k,1])
        f.update(gain_compensation_increment_sim_pct=float(a['gain']),phase_compensation_increment_sim_arcmin=float(a['phase']),
                 cleaning_residue_proxy=a['residue'],rs485_incoming_margin_proxy=a['rs_margin'],lcd_incoming_margin_proxy=a['lcd_margin'],process_sequence_available=0)
        features.append(f)
        traces.append(dict(sample_id=uid,batch_id=r['batch_id'],split=r['split'],source_background_meter=r['source_meter'],ct_source_sample=r['source_ct']+1,crystal_source_sample=r['source_crystal']+1,
                           source_component_file=FILES['component'],ct_source_cells=f'互感器测试数据!U{8+3*r["source_ct"]}:Z{9+3*r["source_ct"]}',crystal_source_cell=f'晶振测试数据!F{3+r["source_crystal"]}',
                           process_source=r['process_source'],mapping_status='虚拟装配，非企业实物配对'))
        assemblies.append(dict(sample_id=uid,batch_id=r['batch_id'],recipe_id=r['recipe_id'],ct_sim_lot=r['ct_lot'],ct_model=metadata['ct_model'],ct_reference_lot=metadata['ct_source_lot'],
                               crystal_sim_lot=r['crystal_lot'],crystal_model=metadata['crystal_model'],crystal_reference_lot=metadata['crystal_source_lot'],crystal_load_capacitance_pF=metadata['crystal_load_capacitance_pF'],
                               crystal_reference_ppm=crystals[r['source_crystal']],crystal_frequency_Hz=None,crystal_frequency_status=metadata['frequency_status'],
                               lcd_sim_lot=r['lcd_lot'],rs485_sim_lot=r['rs485_lot'],assembly_status='仿真装配；晶振只作元件背景，不参与故障',enterprise_barcode=None,meter_model=None,production_date=None))
        calibrations.append(dict(sample_id=uid,gain_compensation_increment_sim_pct=float(a['gain']),phase_compensation_increment_sim_arcmin=float(a['phase']),
                                 reference_ct_ratio_pct=float(ac[r['source_ct'],0,2,0]),reference_ct_phase_arcmin=float(ac[r['source_ct'],0,2,1]),
                                 calibration_anchor='交流100%升流，模拟参考点',hardware_register_gain=None,hardware_register_phase=None,provenance='模拟补偿增量，非实际寄存器写入值'))
        sampling.append(dict(sample_id=uid,batch_id=r['batch_id'],selected_for_aging=int(aged),design_sampling_fraction=c['aging_per_batch']/c['units_per_batch'],method='批内先随机分流，再按结果配额条件选样'))
        logs.append(dict(sample_id=uid,requested_label=label,requested_delayed=int(slot['delayed']),proposal_chain=CHAINS[a['chain']][0],attempts=attempt))
        for d,dn in enumerate(['升','降']):
            for k,label_anchor in enumerate(ANCHORS[:3]):
                row=8+3*r['source_ct']+d
                curve_rows.append(dict(sample_id=uid,direction=dn,anchor=label_anchor,current_fraction_100pct=c['ct_confirmed_fraction_axis'][k],ratio_sim_pct=float(a['curves'][d,k,0]),phase_sim_arcmin=float(a['curves'][d,k,1]),
                                       source_sample=r['source_ct']+1,source_cells=f'{openpyxl.utils.get_column_letter(21+2*k)}{row}:{openpyxl.utils.get_column_letter(22+2*k)}{row}',provenance='同一抽检样品曲线加相关扰动'))
        for row in a['results']:
            t=row['t'];h=row['h'];tid=f'{uid}-T{t}'; missing=';'.join(f'D{s//c["segments_per_digit"]+1}-{chr(97+s%c["segments_per_digit"])}' for s in row['missing'])
            tests.append(dict(test_id=tid,sample_id=uid,batch_id=r['batch_id'],route=slot['route'],test_stage='出厂检测' if not aged else '老化前基线检测' if not h else '老化后恢复检测',exposure_h=h,
                              measurement_temp_C=c['measurement_temp_C'],measurement_RH_pct=c['measurement_RH_pct'],measurement_voltage_Un=c['measurement_voltage_Un'],recovery_h=c['recovery_h'] if h else 0,
                              stress_temp_C=c['stress_temp_C'] if h else None,stress_RH_pct=c['stress_RH_pct'] if h else None,stress_voltage_Un=c['stress_voltage_Un'] if h else None,stress_current_A=c['stress_current_A'] if h else None,
                              ct_sweep_direction=['升','降'][a['direction']],**{f'error_{cond}_pct':float(row['error'][j]) for j,cond in enumerate(CONDITIONS)},comm_trials=c['communication_trials'],comm_failures=row['comm_failures'],comm_success_rate=row['success'],
                              lcd_expected_segments=c['lcd_digits']*c['segments_per_digit'],lcd_missing_segments=len(row['missing']),lcd_missing_positions=missing,metering_fail=row['mf'],communication_fail=row['cf'],display_fail=row['lf'],any_fail=row['bad']))
            for j,cond in enumerate(CONDITIONS):
                decomp.append(dict(test_id=tid,sample_id=uid,condition=cond,power_factor=[1,.5][j%2],current_fraction_100pct_sim=float(eval_axis[j]),ct_mapping_outside_measured_axis=int(eval_axis[j]<axis[0] or eval_axis[j]>axis[-1]),
                                   initial_source_cell=refs[0][r['source_meter']][j],initial_source_pct=float(traj[r['source_meter']][0,j]),initial_perturbation_pct=float(a['base'][j]-traj[r['source_meter']][0,j]),
                                   aging_source_cell=refs[t][r['source_meter']][j] if h else None,aging_background_pct=float(row['age'][j]),ct_residual_ratio_pct=float(row['ratio_res'][j]),ct_residual_phase_rad=float(row['phase_res_rad'][j]),
                                   ct_effect_pct=float(row['ct_effect'][j]),solder_effect_pct=float(row['solder_effect'][j]),residue_effect_pct=float(row['leak_effect'][j]),measurement_noise_pct=float(row['noise'][j]),final_error_pct=float(row['error'][j]),simulation_limit_pct=float(limits[j])))
        # Paired mechanism removal uses identical noise; these are simulated interventions, not repairs.
        actual=[x['bad'] for x in a['results']]
        strengths=[float(max(np.max(abs(a['ratio_res'])),np.max(abs(a['phase_res']))/60)),a['ds'],a['dr'],a['dc'],a['dl']]
        for k,ch in enumerate(CHAINS):
            cf=a['evaluate'](disabled=k); cf_bad=[x['bad'] for x in cf]
            truth.append(dict(sample_id=uid,mechanism=ch[0],upstream=ch[1],component=ch[2],intermediate_defect=ch[3],electrical_effect=ch[4],possible_symptom=ch[5],latent_strength=float(strengths[k]),
                              initial_activation=float(a['initial'][k]),degradation_rate=float(a['rate'][k]),degradation_exponent=a['beta'],truth_only=1,interpretation='机制参数及仿真干预依据，非企业确认根因'))
            counterfactual.append(dict(sample_id=uid,disabled_mechanism=ch[0],observed_fail_any=int(any(actual)),disabled_fail_any=int(any(cf_bad)),
                                       failing_rounds_actual=sum(actual),failing_rounds_disabled=sum(cf_bad),failed_rounds_removed=sum(x and not y for x,y in zip(actual,cf_bad)),
                                       metering_max_abs_actual=float(max(np.max(abs(x['error'])) for x in a['results'])),metering_max_abs_disabled=float(max(np.max(abs(x['error'])) for x in cf)),truth_only=1,
                                       interpretation='同噪声移除单机制；多故障或相互抵消时未必改变总标签，不等同实际维修'))
    batches=[]; recipe_table=[]
    for r in recipes:
        uu=[u for u in units if u['batch_id']==r['batch_id']]; ag=[u for u in uu if u['route']=='加速老化抽测']; fa=[u for u in uu if u['route']=='未老化出厂检测']
        batches.append(dict(batch_id=r['batch_id'],total=len(uu),aging_sample_n=len(ag),factory_only_n=len(fa),aging_negative_n=sum(u['sample_label']=='负样本' for u in ag),aging_new_failure_n=sum(u['aging_new_failure'] for u in ag),factory_negative_n=sum(u['sample_label']=='负样本' for u in fa),split=r['split']))
        recipe_table.append(dict(batch_id=r['batch_id'],recipe_id=r['recipe_id'],recipe_version=r['recipe_version'],**{f'reflow_zone_{j+1:02d}_set_C':v for j,v in enumerate(r['reflow_set_C'])},conveyor_set_cm_min=r['conveyor_set_cm_min'],
                                 **{k:r[k] for k in ['wave_preheat_1_set_C','wave_preheat_2_set_C','wave_preheat_3_set_C','wave_solder_set_C','wave_flux_value_raw','wave_flux_unit','wave_height1_raw','wave_height2_raw','wave_height_unit','process_source','process_scope']}))
    factory=[t for t in tests if t['route']=='未老化出厂检测']; aging=[t for t in tests if t['route']=='加速老化抽测']
    data={'样本主表.csv':units,'批次表.csv':batches,'model_inputs.csv':features,'出厂检测.csv':factory,'加速老化检测.csv':aging,'故障链真值.csv':truth,'来源映射.csv':traces,
          '元件装配.csv':assemblies,'批次配方.csv':recipe_table,'互感器多点曲线.csv':curve_rows,'校准模拟参数.csv':calibrations,'抽样记录.csv':sampling,'计量数值分解.csv':decomp,
          '仿真机制移除对照.csv':counterfactual,'sampling_log.csv':logs}
    proxies=['cleaning_residue_proxy','rs485_incoming_margin_proxy','lcd_incoming_margin_proxy']
    observable=[{k:v for k,v in f.items() if k not in proxies+['process_sequence_available']} for f in features]
    data['model_inputs_observable.csv']=observable
    for name, rows in data.items(): save(out/name,rows)
    summary=dict(version=c['version'],total=len(units),positive=sum(u['sample_label']=='正样本' for u in units),negative=sum(u['sample_label']=='负样本' for u in units),
                 route_labels=dict(Counter(u['route']+' / '+u['sample_label'] for u in units)),statuses=dict(Counter(u['result_scope'] for u in units)),splits=dict(Counter(u['split'] for u in units)),
                 batches=len(batches),test_rows=len(tests),metering_values=len(decomp),source_meters=len(ids),ct_source_specimens=10,crystal_source_specimens=10,
                 curve_rows=len(curve_rows),feature_columns=len(features[0])-1,observable_feature_columns=len(observable[0])-1,proposal_attempts=sum(v['attempts'] for v in logs),max_attempts=max(v['attempts'] for v in logs),
                 failure_domains={route:{dom:len({t['sample_id'] for t in tests if t['route']==route and t[dom]}) for dom in ['metering_fail','communication_fail','display_fail']} for route in ['未老化出厂检测','加速老化抽测']},
                 no_timekeeping_outputs=True)
    contract=dict(join_key='sample_id',primary_features=list(observable[0])[1:],simulation_only_optional_features=proxies,
                  ideal_feature_file='model_inputs.csv',recommended_ablation_file='model_inputs_observable.csv',
                  feature_availability='全部样本为半合成；observable仅移除三项无量纲代理，其他模拟量仍须现场测量/系数解码后才能部署',
                  known_test_conditions=['ct_sweep_direction','route','exposure_h','measurement_temp_C','measurement_RH_pct','measurement_voltage_Un'],
                  forbidden=['sample_label','ID及序号','元件/来源样品ID','故障链真值','计量数值分解','仿真机制移除对照','未来检测','批次最终统计','sampling_log'],
                  crystal_policy='晶振只作装配背景，不进入X或y',timekeeping_policy='不读取、不生成日计时误差或时钟故障',
                  split_policy='背景整表和来料抽检样品身份分组；原始元件仅一个批次，不能声称跨真实批次泛化',sequence_policy='无制造过程时间曲线，process_sequence_available=0',
                  label_policy='按所在路径观察窗的实际生成结果判定，配额条件选样，不代表自然发生率')
    dump(out/'summary.json',summary);dump(out/'model_contract.json',contract);dump(out/'batch_recipes.json',recipes)
    dump(out/'workbook_payload.json',dict(summary=summary,units=units,features=features,factory=factory,aging=aging,assemblies=assemblies,recipes=recipe_table,batches=batches,source_records=raw_records,
                                         curves=curve_rows,calibrations=calibrations,traces=traces,
                                         chains=[dict(zip(['mechanism','upstream','component','defect','effect','symptom'],ch)) for ch in CHAINS]))
    dictionary=[]
    for name, rows in {**data, '元件抽检来源.csv':raw_records}.items():
        for key in rows[0]:
            unit='%' if key.endswith(('_pct','_Un')) else '角分' if key.endswith('arcmin') else '℃' if key.endswith('_C') else 'mm' if key.endswith('_mm') else 'cm/min' if key.endswith('_cm_min') else 'h' if key.endswith('_h') else ''
            if key.endswith('_Un'): unit='Un倍数'
            if key.endswith('_ppm') or key=='crystal_ppm': unit='ppm'
            if key.endswith('_rad'): unit='rad'
            if key.endswith('_pF'): unit='pF'
            if key.endswith('_Hz'): unit='Hz'
            if key=='gain_compensation_increment_sim_pct': unit='百分点'
            if key=='comm_success_rate': unit='0~1比例'
            role='模型特征' if name in ['model_inputs.csv','model_inputs_observable.csv'] and key!='sample_id' else '标识' if key.endswith('_id') else '审计/记录'
            if name in ['故障链真值.csv','仿真机制移除对照.csv','计量数值分解.csv','sampling_log.csv']: role='禁止作为制造预测输入'
            provenance='合成/变换，详见来源与方案'
            if name=='元件抽检来源.csv': provenance='原始单元格值'
            elif 'proxy' in key: provenance='无量纲仿真代理，无企业实测'
            elif '_sim_' in key or key.endswith('_sim_pct'): provenance='明确标记的模拟量'
            dictionary.append(dict(table=name,field=key,unit=unit,role=role,provenance=provenance))
    save(out/'数据字典.csv',dictionary)
    dump(out/'data_hashes.json',{p.name:digest(p) for p in sorted(out.glob('*.csv'))})
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
