"""Independent structural, numerical, provenance and reproducibility checks."""
from pathlib import Path
from collections import Counter, defaultdict
import csv, hashlib, json, math, subprocess, sys, tempfile
import numpy as np
import openpyxl

P=Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding='utf-8')
def rd(n):
    with (P/n).open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
def jd(n): return json.loads((P/n).read_text(encoding='utf-8'))
checks=[]
def ck(name,ok,detail=''):
    checks.append(dict(check=name,passed=bool(ok),detail=detail))
    if not ok: raise AssertionError(name+' '+str(detail))
def n(x,k): return float(x[k])
u=rd('样本主表.csv');f=rd('出厂检测.csv');a=rd('加速老化检测.csv');tr=rd('来源映射.csv')
de=rd('计量数值分解.csv');inputs=rd('model_inputs.csv');obs=rd('model_inputs_observable.csv')
curves=rd('互感器多点曲线.csv');cal=rd('校准模拟参数.csv');raw=rd('元件抽检来源.csv')
ass=rd('元件装配.csv');recipes=rd('批次配方.csv');truth=rd('故障链真值.csv');cf=rd('仿真机制移除对照.csv')
c=jd('config.json');contract=jd('model_contract.json')
ck('1000个唯一表且833正167负',len(u)==1000 and len({x['sample_id'] for x in u})==1000 and Counter(x['sample_label'] for x in u)=={'正样本':833,'负样本':167})
ck('双路径配额',Counter((x['route'],x['sample_label']) for x in u)=={('加速老化抽测','正样本'):166,('加速老化抽测','负样本'):34,('未老化出厂检测','正样本'):667,('未老化出厂检测','负样本'):133})
batches=defaultdict(list);byid=defaultdict(list)
for x in u: batches[x['batch_id']].append(x)
for x in f+a: byid[x['sample_id']].append(x)
ck('每批20台抽4台，共50批',len(batches)==50 and all(len(v)==20 and sum(x['route']=='加速老化抽测' for x in v)==4 for v in batches.values()))
ck('两路径互斥且覆盖1000台',not({x['sample_id'] for x in f}&{x['sample_id'] for x in a}) and set(byid)=={x['sample_id'] for x in u})
ck('800次出厂与1200次老化检测',len(f)==800 and len(a)==1200)
ck('老化六轮出厂一轮',all(sorted(int(v['exposure_h']) for v in byid[x['sample_id']])==(c['hours'] if x['route']=='加速老化抽测' else [0]) for x in u))
ecols=[k for k in f[0] if k.startswith('error_')]; conds=[k[6:-4] for k in ecols]
tests={x['test_id']:x for x in f+a}; um={x['sample_id']:x for x in u};fm={x['sample_id']:x for x in inputs};cm={x['sample_id']:x for x in cal}
for x in f+a:
    errors=np.array([n(x,k) for k in ecols]); mf=int(np.any(abs(errors)>c['error_limits_pct']))
    rate=(int(x['comm_trials'])-int(x['comm_failures']))/int(x['comm_trials'])
    cf0=int(rate<c['communication_min_success_rate']);lf=int(int(x['lcd_missing_segments'])>0)
    assert abs(rate-n(x,'comm_success_rate'))<1e-12 and 0<=rate<=1
    assert [mf,cf0,lf,int(bool(mf or cf0 or lf))]==[int(x[k]) for k in ['metering_fail','communication_fail','display_fail','any_fail']]
    assert int(x['lcd_expected_segments'])==42
    missing=x['lcd_missing_positions'].split(';') if x['lcd_missing_positions'] else []
    assert len(set(missing))==len(missing)==int(x['lcd_missing_segments'])
    assert n(x,'measurement_temp_C')==23 and n(x,'measurement_RH_pct')==50 and n(x,'measurement_voltage_Un')==1
    if int(x['exposure_h'])>0:
        assert [n(x,k) for k in ['stress_temp_C','stress_RH_pct','stress_voltage_Un','stress_current_A','recovery_h']]==[85,85,1.1,60,1]
    else:
        assert all(x[k]=='' for k in ['stress_temp_C','stress_RH_pct','stress_voltage_Un','stress_current_A']) and x['recovery_h']=='0'
ck('2000次检测标志由数值重新判定，显示通信计数一致',True)
ck('强化受应力与恢复后检测条件明确分离',True)
for x in u:
    rs=sorted(byid[x['sample_id']],key=lambda z:int(z['exposure_h']));bad=[r for r in rs if r['any_fail']=='1']
    assert (x['sample_label']=='负样本')==bool(bad)
    assert x['first_observed_fail_h']==(bad[0]['exposure_h'] if bad else '')
    assert int(x['initial_test_fail'])==int(rs[0]['any_fail']) and x['lifetime_health']=='未知'
    if x['aging_new_failure']=='1': assert rs[0]['any_fail']=='0' and int(x['first_observed_fail_h'])>0
ck('主标签与首检时间可从结果复算',True)
ck('老化24台新检出和10台基线异常',sum(x['aging_new_failure']=='1' for x in u)==24 and sum(x['result_scope']=='老化前已异常' for x in u)==10)
for field in ['batch_id','source_background_meter','ct_source_sample','crystal_source_sample']:
    splitmap=defaultdict(set)
    for x in tr: splitmap[x[field]].add(x['split'])
    ck(field+'不跨数据划分',all(len(v)==1 for v in splitmap.values()))
ck('来源表仅29条完整轨迹',len({x['source_background_meter'] for x in tr})==29)
ck('抽样记录与主表一致',all((s['selected_for_aging']=='1')==(um[s['sample_id']]['route']=='加速老化抽测') for s in rd('抽样记录.csv')))
ck('数据及元件来源身份均完整',all(len(v)==1000 and len({x['sample_id'] for x in v})==1000 for v in [inputs,obs,tr,cal,ass]))
ck('制造输入无标签来源身份和未来结果',set(obs[0])=={'sample_id',*contract['primary_features']} and not(set(inputs[0])&{'sample_label','latent_strength','first_observed_fail_h','batch_id','source_background_meter','route'}))
ck('无时钟或晶振模型输入',not any(any(z in k.lower() for z in ['timekeeping','clock','crystal','日计时','时钟']) for k in inputs[0]))
ck('无制造过程伪时序',all(x['process_sequence_available']=='0' for x in inputs))
ck('模型输入无完全重复向量',len({tuple(v for k,v in x.items() if k!='sample_id') for x in obs})==1000)
ck('三项代理消融文件严格移除',all({k:v for k,v in x.items() if k not in contract['simulation_only_optional_features']+['process_sequence_available']}==y for x,y in zip(inputs,obs)))
ck('原始来源哈希一致',all(hashlib.sha256((P/'sources'/x['file']).read_bytes()).hexdigest()==x['sha256'] for x in jd('source_manifest.json')))
# Compare every retained original component observation directly to its cited cells.
wc=openpyxl.load_workbook(P/'sources'/jd('source_manifest.json')[1]['file'],data_only=True,read_only=True)
grids={s:list(wc[s].iter_rows(min_row=1,max_row=37 if s=='互感器测试数据' else 12,max_col=32 if s=='互感器测试数据' else 6,values_only=True)) for s in ['互感器测试数据','晶振测试数据']}
for x in raw:
    cell=x['source_cells'].split(':')[0];row,col=openpyxl.utils.cell.coordinate_to_tuple(cell);g=grids[x['source_sheet']]
    if x['component']=='晶振': assert n(x,'crystal_ppm')==float(g[row-1][col-1])
    else: assert n(x,'ratio_pct')==float(g[row-1][col-1]) and n(x,'phase_arcmin')==float(g[row-1][col])
wc.close()
ck('270条原始来料观测逐单元格一致',len(raw)==270)
ck('抗直流80条独立保存且不误作交流',sum(x['test_regime']=='抗直流' for x in raw)==80 and all(x['current_fraction_100pct']=='' for x in raw if x['test_regime']=='抗直流'))
ck('互感器6000条曲线仅含已标明的前三相对锚点',len(curves)==6000 and {x['anchor'] for x in curves}=={'5%','20%','100%'})
cvmap=defaultdict(dict)
for x in curves:
    uid=x['sample_id'];dn={'升':'up','降':'down'}[x['direction']];kn={'5%':'005','20%':'020','100%':'100'}[x['anchor']]
    assert n(x,'ratio_sim_pct')==n(fm[uid],f'ct_{dn}_{kn}_ratio_sim_pct') and n(x,'phase_sim_arcmin')==n(fm[uid],f'ct_{dn}_{kn}_phase_sim_arcmin')
    cvmap[uid][(dn,kn)]=x
for uid,x in cm.items():
    assert n(x,'gain_compensation_increment_sim_pct')==n(fm[uid],'gain_compensation_increment_sim_pct')
    assert n(x,'phase_compensation_increment_sim_arcmin')==n(fm[uid],'phase_compensation_increment_sim_arcmin')
    assert x['hardware_register_gain']==x['hardware_register_phase']==''
ck('曲线与模型特征完全一致且补偿未冒充硬件寄存器',True)
wa=openpyxl.load_workbook(P/'sources'/jd('source_manifest.json')[0]['file'],data_only=True,read_only=True)
ag=list(wa['基本误差'].iter_rows(min_row=1,max_row=67,max_col=32,values_only=True));wa.close()
maxsum=0;maxct=0;max_interp=0
latent={(x['sample_id'],x['mechanism']):x for x in truth}
for x in de:
    uid=x['sample_id'];j=conds.index(x['condition']);test=tests[x['test_id']];h=int(test['exposure_h']);t=h//200
    total=sum(n(x,k) for k in ['initial_source_pct','initial_perturbation_pct','aging_background_pct','ct_effect_pct','solder_effect_pct','residue_effect_pct','measurement_noise_pct'])
    maxsum=max(maxsum,abs(total-n(x,'final_error_pct')))
    assert n(x,'final_error_pct')==n(test,ecols[j]) and n(x,'simulation_limit_pct')==c['error_limits_pct'][j]
    r0,c0=openpyxl.utils.cell.coordinate_to_tuple(x['initial_source_cell']);assert n(x,'initial_source_pct')==float(ag[r0-1][c0-1])
    if um[uid]['route']=='未老化出厂检测': assert x['aging_source_cell']=='' and n(x,'aging_background_pct')==0
    if h:
        rt,ct=openpyxl.utils.cell.coordinate_to_tuple(x['aging_source_cell']);delta=float(ag[rt-1][ct-1])-float(ag[r0-1][c0-1])
        if abs(delta)>1e-12: assert .35-1e-9<=n(x,'aging_background_pct')/delta<=.8+1e-9
    bg=sum(n(x,k) for k in ['initial_source_pct','initial_perturbation_pct','aging_background_pct'])
    phi=math.acos(n(x,'power_factor')); expected=100*((1+bg/100)*(1+n(x,'ct_residual_ratio_pct')/100)*math.cos(phi+n(x,'ct_residual_phase_rad'))/math.cos(phi)-1)-bg
    maxct=max(maxct,abs(expected-n(x,'ct_effect_pct')))
    lct=latent[(uid,'CT_RESIDUAL')];growth=n(lct,'initial_activation')+n(lct,'degradation_rate')*(h/1000)**n(lct,'degradation_exponent')
    dn={'升':'up','降':'down'}[test['ct_sweep_direction']];axis=c['ct_confirmed_fraction_axis'];where=c['condition_current_fraction_sim'][j//2]
    raw_ratio=np.interp(where,axis,[n(cvmap[uid][dn,kn],'ratio_sim_pct') for kn in ['005','020','100']])
    raw_phase=np.interp(where,axis,[n(cvmap[uid][dn,kn],'phase_sim_arcmin') for kn in ['005','020','100']])
    rr=(raw_ratio-n(cm[uid],'reference_ct_ratio_pct')+n(cm[uid],'gain_compensation_increment_sim_pct'))*growth
    pp=(raw_phase-n(cm[uid],'reference_ct_phase_arcmin')+n(cm[uid],'phase_compensation_increment_sim_arcmin'))*growth*math.pi/10800
    max_interp=max(max_interp,abs(rr-n(x,'ct_residual_ratio_pct')),abs(pp-n(x,'ct_residual_phase_rad')))
    assert int(x['ct_mapping_outside_measured_axis'])==int(where<axis[0] or where>axis[-1])
ck('20000项误差分解可重建',len(de)==20000 and maxsum<5.01e-7,str(maxsum))
ck('CT功率响应公式可独立重算',maxct<1e-10,str(maxct))
ck('多点曲线与补偿量实际参与响应且插值正确',max_interp<1e-10,str(max_interp))
ck('未老化样本只用第零轮背景且老化增量范围正确',True)
ck('装配未伪造企业型号条码日期频率',all(all(x[k]=='' for k in ['enterprise_barcode','meter_model','production_date','crystal_frequency_Hz']) for x in ass))
ck('设置值与模拟读数分开且波峰未编造单位',all(x['wave_flux_unit']==x['wave_height_unit']=='' for x in recipes) and all(n(x,'conveyor_set_cm_min')==100 for x in recipes) and any(n(x,'conveyor_reading_sim_cm_min')!=100 for x in inputs))
ck('5000条机制与5000条同噪声移除对照完整',len(truth)==5000 and len(cf)==5000 and all(x['truth_only']=='1' for x in truth+cf))
for x in cf:
    assert int(x['observed_fail_any'])==int(um[x['sample_id']]['sample_label']=='负样本')
    if x['disabled_mechanism'] in ['RS485_JOINT','LCD_CONTACT']:
        assert int(x['failing_rounds_disabled'])<=int(x['failing_rounds_actual'])
        assert abs(n(x,'metering_max_abs_actual')-n(x,'metering_max_abs_disabled'))<1e-12
ck('机制移除对照与主标签一致，通信显示移除不改变计量',True)
for name,sha in jd('data_hashes.json').items(): assert hashlib.sha256((P/name).read_bytes()).hexdigest()==sha
ck('所有CSV哈希一致',True)
# Verify identical random seed + sources + config reproduces all CSVs in an isolated directory.
with tempfile.TemporaryDirectory(prefix='meter_v3_repro_') as tmp:
    subprocess.run([sys.executable,str(P/'generate_v3.py'),'--raw',str(P/'sources'),'--config',str(P/'config.json'),'--out',tmp],check=True,stdout=subprocess.DEVNULL)
    for name,sha in jd('data_hashes.json').items(): assert hashlib.sha256((Path(tmp)/name).read_bytes()).hexdigest()==sha,name
ck('固定种子全量重跑CSV逐字节可复现',True)
effects={ch:sum(int(x['failed_rounds_removed'])>0 for x in cf if x['disabled_mechanism']==ch) for ch in {x['disabled_mechanism'] for x in cf}}
ck('五条机制均有非零结果影响',all(v>0 for v in effects.values()),str(effects))
# Descriptive overlap only. It does not validate empirical realism.
overlap={}
for k in ['conveyor_reading_sim_cm_min','placement_offset_sim_mm','gain_compensation_increment_sim_pct','ct_up_100_ratio_sim_pct']:
    pv=[n(x,k) for x in inputs if um[x['sample_id']]['sample_label']=='正样本'];nv=[n(x,k) for x in inputs if um[x['sample_id']]['sample_label']=='负样本']
    overlap[k]={'positive_min_max':[min(pv),max(pv)],'negative_min_max':[min(nv),max(nv)],'ranges_overlap':max(min(pv),min(nv))<=min(max(pv),max(nv))}
near=sum(x['sample_label']=='正样本' and any(max(abs(n(t,k))/lim for k,lim in zip(ecols,c['error_limits_pct']))>.8 for t in byid[x['sample_id']]) for x in u)
report=dict(check_count=len(checks),passed=all(x['passed'] for x in checks),checks=checks,mechanism_removal_with_round_effect=effects,feature_range_overlap=overlap,positive_near_metering_threshold_80pct=near,
            limitations=['仅验证仿真内部一致性、来源与可复现性，未验证企业真实因果、精度或故障率。','相对电流映射、响应参数和判定阈值为仿真假设，轴外CT响应保持端点。','833/167为条件选样配额；1000条不等于1000台独立实测电表。'])
(P/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False,indent=2))
