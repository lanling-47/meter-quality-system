"""Verify saved XLSX against the generation payload and package the deliverable."""
from pathlib import Path
from PIL import Image,ImageOps,ImageDraw,ImageFont
import hashlib,json,math,sys,zipfile
import openpyxl
P=Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding='utf-8')
def jd(n):return json.loads((P/n).read_text(encoding='utf-8'))
payload=jd('workbook_payload.json');manifest=jd('workbook_manifest.json')
book=P/'电表双路径正负样本_1000条_v3_补充版.xlsx'
w=openpyxl.load_workbook(book,data_only=True,read_only=True)
checked=0;tablecounts={}
for m in manifest:
    s=w[m['sheet']];rows=list(s.iter_rows(values_only=True))
    assert len(rows)==m['rows']+1,(s.title,len(rows),m['rows'])
    assert list(rows[0])==m['headers'],s.title
    for actual,record in zip(rows[1:],payload[m['key']]):
        expected=[record.get(k) for k in m['fields']]
        for x,y in zip(actual,expected):
            if isinstance(y,(int,float)) and not isinstance(y,bool):
                assert isinstance(x,(int,float)) and math.isclose(x,y,rel_tol=1e-12,abs_tol=1e-12),(s.title,x,y)
            else:
                assert x==(None if y=='' else y),(s.title,x,y)
            assert not (isinstance(x,str) and x.startswith(('#REF!','#DIV/0!','#VALUE!','#NAME?','#NUM!','#N/A','#NULL!','#SPILL!','#CALC!')))
            checked+=1
    tablecounts[s.title]=m['rows']
summary={'B5':667,'C5':133,'D5':800,'B6':166,'C6':34,'D6':200,'B7':833,'C7':167,'D7':1000,'B9':833/167,'B13':10,'B14':24,'B18':640,'B19':180,'B20':180}
for cell,expected in summary.items():assert math.isclose(w['总览'][cell].value,expected,rel_tol=1e-12),cell
w.close()
wf=openpyxl.load_workbook(book,data_only=False,read_only=True)
for cell in summary: assert wf['总览'][cell].data_type=='f',cell
wf.close()
report=dict(passed=True,sheets=len(manifest)+1,checked_data_cells=checked,table_rows=tablecounts,summary_formula_cells=len(summary),formula_cached_values_match=True,
            scope='导出XLSX逐单元格与生成数据核对；汇总公式及缓存值核对。未通过桌面Excel执行交互修改。')
(P/'workbook_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
if '--contact' in sys.argv:
    imgs=sorted((P/'previews').glob('*.png'))
    font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18)
    for k in range(0,len(imgs),4):
        group=imgs[k:k+4];canvas=Image.new('RGB',(1400,1050),'#E3E9EF');draw=ImageDraw.Draw(canvas)
        for j,fp in enumerate(group):
            x=(j%2)*700;y=(j//2)*525
            im=Image.open(fp).convert('RGB');im.thumbnail((690,485))
            canvas.paste(im,(x+5,y+32));draw.text((x+10,y+4),fp.stem,fill='#263F5B',font=font)
        canvas.save(P/'previews'/f'contact_{k//4+1}.jpg')
if '--package' in sys.argv:
    # Do not traverse node_modules junction or include transient render/payload/inspect files.
    chosen=[f for f in P.iterdir() if f.is_file() and (f.suffix in ['.csv','.py','.mjs','.md','.xlsx'] or f.name in ['config.json','summary.json','model_contract.json','source_manifest.json','data_hashes.json','validation_report.json','原始规格与配方.json','batch_recipes.json','workbook_manifest.json','workbook_verification.json'])]
    chosen+=list((P/'sources').glob('*.xlsx'))
    manifesthash={str(f.relative_to(P)).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(chosen)}
    (P/'package_sha256.json').write_text(json.dumps(manifesthash,ensure_ascii=False,indent=2),encoding='utf-8')
    chosen.append(P/'package_sha256.json')
    dest=P.parent/'电表双路径样本_v3_1000台_补充数据与生成依据.zip'
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for f in sorted(chosen):z.write(f,str(f.relative_to(P)))
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        for name,sha in manifesthash.items(): assert hashlib.sha256(z.read(name)).hexdigest()==sha
    print('PACKAGE '+str(dest)+' '+str(dest.stat().st_size)+' bytes; '+str(len(chosen))+' files; hash verification passed')
